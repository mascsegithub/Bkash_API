<?php

return [
    'username' => env('BKASH_USERNAME', null),

    'password' => env('BKASH_PASSWORD', null),

    'mobile' => env('BKASH_MOBILE', null)
];
